<?php
require_once 'configBD.php';

use Illuminate\Database\Eloquent\Model;

Class BancoDadosGlobal extends Model {}